using SME;
using System;
using System.Threading.Tasks;

/*Add to main program:
                        //Simulation
                        var creater = new Creater();
                        var printer = new Printer();

                        var a1 = Scope.CreateBus<tdata>();
                        creater.a1=a1;
                        printer.a2=a2;
                        inst0.a1=a1
 */
namespace BohSME
{

    public class Creater : SimulationProcess
    {
        [OutputBus]
        public tdata a1;

        private int len = 9;

        public override async Task Run()
        {
            await ClockAsync();
            for(int i =0; i<len; i++){
                a1.val=i;
                await ClockAsync();
            }
            for(int i =0; i<6; i++){
                await ClockAsync();
            }
        }
    }

    public class  Printer : SimulationProcess
    {
        [InputBus]
        public tdata a2;

        public override async Task Run()
        {
            for(;;){
                await ClockAsync();
                Console.WriteLine("{0}", a2.val);
            }
        }
    }
}

