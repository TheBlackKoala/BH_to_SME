using SME;
using static BohSME.ValuesConfig;

namespace BohSME
{
	[ClockedProcess]
	public class instr0 : SimpleProcess
	{
		[OutputBus]
		public tdata a0l1;

		[InputBus]
		public tdata a1l0;

		int minLen ;
		protected override void OnTick()
		{
			if (a1l0.valid){
				minLen = a1l0.len;
				a0l1.valid = true;
				a0l1.len = minLen;
				for(int i = 0; i< ValuesConfig.len - 1+1; i++){
					if (i<minLen){
						a0l1.val[i] = a1l0.val[i] + a1l0.val[i];
					}
				}
			}
			else{
				a0l1.valid = false;
			}
		}
	}

	[ClockedProcess]
	public class instr1 : SimpleProcess
	{
		[OutputBus]
		public tdata a2l2;

		[InputBus]
		public tdata a0l1;

		int minLen ;
		protected override void OnTick()
		{
			if (a0l1.valid){
				minLen = a0l1.len;
				a2l2.valid = true;
				a2l2.len = minLen;
				for(int i = 0; i< ValuesConfig.len - 1+1; i++){
					if (i<minLen){
						a2l2.val[i] = a0l1.val[i] + 2;
					}
				}
			}
			else{
				a2l2.valid = false;
			}
		}
	}

	[ClockedProcess]
	public class instr2 : SimpleProcess
	{
		[OutputBus]
		public tdata a3l3;

		[InputBus]
		public tdata a0l2;

		[InputBus]
		public tdata a2l2;

		int minLen ;
		protected override void OnTick()
		{
			if (a0l2.valid && a2l2.valid){
				minLen = a0l2.len;
				if (minLen > a2l2.len){
					minLen = a2l2.len;
				}
				a3l3.valid = true;
				a3l3.len = minLen;
				for(int i = 0; i< ValuesConfig.len - 1+1; i++){
					if (i<minLen){
						a3l3.val[i] = a0l2.val[i] + a2l2.val[i];
					}
				}
			}
			else{
				a3l3.valid = false;
			}
		}
	}

	[ClockedProcess]
	public class repeater : SimpleProcess
	{
		[OutputBus]
		public tdata output;

		[InputBus]
		public tdata input;

		protected override void OnTick()
		{
			if (input.valid){
				output.valid=true;
				for(int i = 0; i< ValuesConfig.len -1+1; i++){
					if ( i < input.len){
						output.val[i] = input.val[i];
					}
				}
				output.len = input.len;
			}
			else{
				output.valid = false;
			}
		}
	}

}
