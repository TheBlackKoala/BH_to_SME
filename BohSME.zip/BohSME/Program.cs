using SME;
using static BohSME.ValuesConfig;

namespace BohSME
{
	class MainClass
	{
		public static void setup(){
			var inst0 = new instr0();
			var inst1 = new instr1();
			var inst2 = new instr2();
			var repa0l2 = new repeater();
			var repa0l3 = new repeater();
			var repa1l1 = new repeater();
			var repa1l2 = new repeater();
			var repa1l3 = new repeater();
			var repa2l3 = new repeater();
			var a0l2 = Scope.CreateBus<tdata>();
			repa0l2.output = a0l2;
			repa0l3.input = a0l2;
			var a1 = Scope.CreateBus<tdata>();
			repa1l1.input = a1;
			var a1l1 = Scope.CreateBus<tdata>();
			repa1l1.output = a1l1;
			repa1l2.input = a1l1;
			var a1l2 = Scope.CreateBus<tdata>();
			repa1l2.output = a1l2;
			repa1l3.input = a1l2;
			var a0l1 = Scope.CreateBus<tdata>();
			inst0.a0l1 = a0l1;
			repa0l2.input = a0l1;
			inst0.a1l0 = a1;
			var a2l2 = Scope.CreateBus<tdata>();
			inst1.a2l2 = a2l2;
			repa2l3.input = a2l2;
			inst1.a0l1 = a0l1;
			inst2.a0l2 = a0l2;
			inst2.a2l2 = a2l2;
			var a2l3 = Scope.CreateBus<tdata>();
                        var a3l3 = Scope.CreateBus<tdata>();
			repa2l3.output = a2l3;
			var a2 = a2l3;
			inst2.a3l3 = a3l3;
                        var creater = new Creater();
                        var printer = new Printer();
                        var sink1 = new Sink();
                        var sink2 = new Sink();
                        var sink3 = new Sink();

                        creater.a1=a1;
                        var a3 = a3l3;
                        printer.a3=a3;
                        sink1.input=a2l3;
                        sink2.input=repa0l3.output;
                        sink3.input=repa1l3.output;
                        var a1l0= a1;
			//Connect  a1 to all l0 channels
			Simulation.Current.AddTopLevelInputs( a1 );
			//Connect  a3, a2 to the highest level channels with the corresponding name
			Simulation.Current.AddTopLevelOutputs( a3, a2 );
		}

		public static void Main(string[] args)
		{

			using(var sim = new Simulation())
			{

				setup();

				// Use fluent syntax to configure the simulator.
				// The order does not matter, but `Run()` must be
				// the last method called.

				// The top-level input and outputs are exposed
				// for interfacing with other VHDL code or board pins

				sim
					.AddTopLevelOutputs()
					.AddTopLevelInputs()
					.BuildCSVFile()
					.BuildVHDL()
					.Run();

				// After `Run()` has been invoked the folder
				// `output/vhdl` contains a Makefile that can
				// be used for testing the generated design
			}
		}
	}
}
